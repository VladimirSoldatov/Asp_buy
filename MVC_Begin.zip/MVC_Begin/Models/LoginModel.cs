﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVC_Begin.Models
{
    public class LoginModel
    {
    }
}
