﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVC_Begin.Models
{
    public class Phone
    {
        public int Id { set; get; }
        public string Company { set; get; }
        public string Model { set; get; }
        public float Price { set; get; }
    }
}
